package com.monott;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonottApplicationTests {

	@Test
	void contextLoads() {
	}

}
